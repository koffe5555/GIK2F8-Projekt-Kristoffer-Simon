DROP TABLE IF EXISTS users;
CREATE TABLE IF NOT EXISTS users (
    email varchar(128) UNIQUE NOT NULL,
    firstname varchar(32) NOT NULL,
    lastname varchar(32) NOT NULL,
    user_type INTEGER CHECK(user_type < 3),
    password varchar(128),
    blocked INTEGER(3),
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE);

INSERT INTO users (email,firstname,lastname,password,user_type,blocked) VALUES
    ('superadmin', 'Kristoffer', 'Palmgren', 'admin', 0, NULL),
    ('consumer', 'Klas', 'Eriksson', 'consumer', 2, NULL),
    ('contributor', 'Simon', 'Rydvall', 'contributor', 1, NULL);

DROP TABLE IF EXISTS question;
CREATE TABLE IF NOT EXISTS question (
    title varchar(32) NOT NULL,
    text varchar(128) NOT NULL,
    date DATETIME,
    category varchar(32) NOT NULL,
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE,
    user varchar(32),
    dupe INTEGER(3)
);

INSERT INTO question (title, text, date, category, question_key) VALUES
    ('Help', 'can someone help me', datetime('now','localtime'), 'FAQ', 1);

DROP TABLE IF EXISTS answer;
CREATE TABLE IF NOT EXISTS answer(
    answertext varchar(128) NOT NULL,
    date DATETIME,
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE,
    user varchar(32),
    rating varchar(3),
    questId INTEGER(5) NOT NULL
);

INSERT INTO question (title, text, category, date, user, dupe) VALUES
    ('fungerar', 'Fungerar detta som det ska?', 'fråga', DATETIME('now'), "h19@kripa.se", 0)

INSERT INTO answer (answertext, date, user, rating, questId) VALUES
    ('Ja DEt fungerar', DATETIME('now'), "h19@kripa.se", 2, 3)




