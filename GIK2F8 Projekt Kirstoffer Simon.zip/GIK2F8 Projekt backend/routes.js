const routes = require('express').Router();
const dbService = require('./database');
const { PRIORITY_ABOVE_NORMAL } = require('constants');


//GET ALL QUESTIONS
routes.get('/question', async (req, res) => {
    try {
        const quest = await dbService.GetAllQuestions();
        res.send(quest);
    }
    catch (error) {
        res.send('Could not get the questions from the database!')
    }
});

//GET ALL ANSWERS
routes.get('/answer', async (req, res) => {
    try {
        const answer = await dbService.GetAllAnswers();
        res.send(answer);
    }
    catch (error) {
        res.send('Could not get the answers from the database!')
    }
});


//GET QUESTION BY ID
routes.get('/question/:id', async (req, res) => {
    if (isNaN(req.params.id) == true) {
        res.send('Enter a number!')
    }
    else {
        try {
            const id = req.params.id;
            const prod = await dbService.GetQuestionId(id);
            res.send(prod);
        }
        catch (error) {
            res.send('Could not get the question from the database!');
        }
    }

});

//DELETE QUESTION BY ID
routes.delete('/question/:id', async (req, res) => {
    if (isNaN(req.params.id) == true) {
        res.send('Enter a number!')
    }
    else {
        try {
            const id = req.params.id;
            const prod = await dbService.DeleteQuestion(id);
            res.send({ 'status': 'ok' });
        }
        catch (error) {
            res.send('Could not Delete the question!');
        }
    }

});

//DELETE ANSWER
routes.delete('/answer/:id', async (req, res) => {
    if (isNaN(req.params.id) == true) {
        res.send('Enter a number!')
    }
    else {
        try {
            const id = req.params.id;
            const prod = await dbService.DeleteAnswer(id);
            res.send({ 'status': 'ok' });
        }
        catch (error) {
            res.send('Could not Delete the question!');
        }
    }
});

//DELETE QUEST ID ANSWER
routes.delete('/answerqid/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const prod = await dbService.DeleteAnswerQID(id);
        res.send({ 'status': 'ok' });
    }
    catch (error) {
        res.send('Could not Delete the question!');
    }
});

//GET ANSWER ID
routes.get('/answer/:id', async (req, res) => {
    if (isNaN(req.params.id) == true) {
        res.send('Enter a number!')
    }
    else {
        try {
            const id = req.params.id;
            const answer = await dbService.GetAnswerId(id);
            res.send(answer);
        }
        catch (error) {
            res.send('Could not get the question from the database!');
        }
    }
});

//GET ANSWER QUESTID
routes.get('/answerId/:id', async (req, res) => {
    try {
        const id = req.params.id
        const answer = await dbService.getAnswer(id);
        res.send(answer);
    }
    catch (error) {
        console.log('något gick fel med hämtning av svar')
    }
});

//POST QUESTION
routes.post('/question', async (req, res) => {

    try {
        const question = await dbService.PostQuestion(req.body);
        res.send(question);
    }
    catch (error) {
        res.send('Could not post the question to the database!');
    }
});

//POST ANSWER
routes.post('/answer', async (req, res) => {

    try {
        const answer = await dbService.PostAnswer(req.body);
        res.send(answer);
    }
    catch (error) {
        res.send('Could not post the question to the database!');
    }
});

//UPDATE QUESTION
routes.put('/question', async (req, res) => {
    if (req.body.title == 0 || req.body.text == 0 || req.body.category == 0 || req.body.id == 0) {
        res.send('Please fill in all fields');
    }
    else {
        try {
            const update = await dbService.UpdateQuestion(req.body)
            res.send({ 'status': 'ok' });

        }
        catch (error) {
            res.send('Could not update the product!');
        }
    }
});

//UPDATE ANSWWER
routes.put('/answer', async (req, res) => {
    if (req.body.answertext == ("") || req.body.id == (""))
    {
        res.send('Fill in all fields!')
    }
    else
    {
        if(isNaN(req.body.id))
        {
            res.send('Id must be an integer!')
        }
        else
        {
            try{
                const answer = await dbService.UpdateAnswer(req.body)
                res.send(answer)
            }
            catch(error)
            {
                console.log('Could not update answers in routes!')
            }
        }
    }
});

//LOGIN
routes.post('/login', async (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    try {
        const user = await dbService.login(req.body);
        if (user.length == undefined) {
            res.send('Wrong email or passowrd!')
        }
        else {
            res.json(user)
        }
    }
    catch (error) {
        res.send(error)
    }


});
// ADD USER
routes.post('/adduser', async (req, res) => {
    try {
        if (req.body.email == ("") || req.body.firstname == ("") || req.body.lastname == ("") || req.body.password == ("")) {
            res.send('Fill all fields!');
            console.log('Fill all fields!');
        }
        else {
            const user = await dbService.PostUser(req.body);
            res.json(user);
        }
    }
    catch (error) {
        res.send('Error could not add user!');
        console.log(error);
    }
});

//GET ALL USER

routes.get('/users', async (req, res) => {
    try{
        const user = await dbService.getUsers();
        res.send(user);
    }
    catch(error)
    {
        console.log('Could not get users from routes!');
    }
});

//GET USER ID
routes.get('/user/:id', async (req, res) => {
    try {
        const id = req.params.id
        const user = await dbService.getUser(id);
        res.send(user);
    }
    catch (error) {
        console.log('Could not get users by ID from routes!')
    }
});

//EDIT USER 
routes.put('/user', async (req, res) => {
    
    try {
        const res = await dbService.updateUser(req.body);
    }
    catch (error) {
        console.log(error)
    }
    res.json({ status: 'user has been updated' }); 
});

//DELETE USER
routes.delete('/user/:id', async (req, res) => {
    try {
        const proddel = await dbService.removeUser(req.params);
        if(proddel == undefined)
        {
            res.send('No such user has been found')
        }
        else
        {
            res.send('User has been removed');
        }
    }
    catch(error) {
        console.log(error);
    }
});

module.exports = routes;