const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const { stat } = require('fs');


const dbPromise = (async () => {
    return open ({
        filename: './database.sqlite',
        driver: sqlite3.Database
    });
})();

//DATE
// source: https://stackoverflow.com/Questions/3605214/javascript-add-leading-zeroes-to-date
function makeDate() {
    var date = new Date();
    var dateStr =
    date.getFullYear() + "-" +
    ("00" + (date.getMonth() + 1)).slice(-2) + "-" +
    ("00" + date.getDate()).slice(-2) + " " +
  
    ("00" + date.getHours()).slice(-2) + ":" +
    ("00" + date.getMinutes()).slice(-2) + ":" +
    ("00" + date.getSeconds()).slice(-2);
    return dateStr
}

//LOGIN
const login = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const user = dbCon.all('SELECT email, firstname, lastname, user_type, blocked, id FROM users WHERE email = ? AND password = ?',[data.email,data.password]);
        return user;
    }
    catch(error)
    {
        console.log('Could not get the Login from the database!')
    }
};
 
//GET ALL QUESTIONS
const GetAllQuestions = async () => {
    try{
        const dbCon = await dbPromise;
        const all = await dbCon.all('SELECT * FROM question ORDER BY title DESC');
        return all;
    }
    catch(error){
        console.log('Could not get the questions from the database!')
    }
}

//GET ALL ANSWERS
const GetAllAnswers = async () => {
    try{
        const dbCon = await dbPromise;
        const all = await dbCon.all('SELECT * FROM answer ORDER BY answertext DESC');
        return all;
    }
    catch(error){
        console.log('Could not get the questions from the database!')
    }
}

//GET QUESTION ID
const GetQuestionId = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prod =  dbCon.get('SELECT * FROM question WHERE id = ?', [data]);
        return prod;
    }
    catch(error)
    {
        console.log('Could not get product id from database!')
    }
};

//DELETE QUESTION ID
const DeleteQuestion = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prodDelete = dbCon.get('DELETE FROM question WHERE id = ?', [data]);
        return prodDelete;
    }
    catch (error)
    {
        console.log('Could not delete id from database!')
    }
};

//DELETE ANSWER ID
const DeleteAnswer = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const Delete = dbCon.get('DELETE FROM answer WHERE id = ?', [data]);
        return Delete;
    }
    catch (error)
    {
        console.log('Could not delete id from database!')
    }
};

//REMOVE ANSWER QUEST ID
const DeleteAnswerQID = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const Delete = dbCon.get('DELETE FROM answer WHERE questId = ?', [data]);
        return Delete;
    }
    catch (error)
    {
        console.log('Could not delete id from database!')
    }
};

//GET ANSWER ID
const GetAnswerId = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prod =  dbCon.get('SELECT * FROM answer WHERE id = ?', [data]);
        return prod;
    }
    catch(error)
    {
        console.log('Could not get product id from database!')
    }
};

//GET ANSWER QUESTID
const GetAnswer = async (data) => {
    try
    {
        const dbCon = await dbPromise;
        const prod =  dbCon.get('SELECT * FROM answer WHERE questId = ?', [data]);
        return prod;
    }
    catch(error)
    {
        console.log('Could not get product id from database!')
    }
};


//POST QUESTION
const PostQuestion = async (data) => {
    try{
        date = makeDate()
        const dbCon = await dbPromise;
        const quest = dbCon.run('INSERT INTO question (title, text, date, category, user, dupe) VALUES(?, ?, ?, ?, ?, ?)', [data.title, data.text, date, data.category, data.user, data.dupe]);
        return {status: 'ok'};
    }
    catch(error)
    {
        console.log('Could not post to the database!')
    }
};
//POST ANSWER
const PostAnswer = async (data) => {
    try{
        date = makeDate()
        const dbCon = await dbPromise;
        const quest = dbCon.run('INSERT INTO answer (answertext, date, user, rating, questId) VALUES(?, ?, ?, ?, ?)', [data.answertext, date, data.user, data.rating, data.questId]);
        return {status: 'ok'};
    }
    catch(error)
    {
        console.log('Could not post to the database!')
    }
};

//UPDATE QUESTION
const UpdateQuestion = async(data) => {
    try
    {
        date = makeDate()
        const dbCon = await dbPromise;
        await dbCon.run('UPDATE question SET title = ?, text = ?, date = ?, category=?, dupe = ? WHERE id = ?',[data.title, data.text,date,data.category, data.dupe, data.id]);
    }
    catch(error)
    {
        console.log('Could not update product in database!');
    }
};

//UPDATE ANSWER
const UpdateAnswer = async(data) => {
    try
    {
        const dbCon = await dbPromise;
        await dbCon.run('UPDATE answer SET answertext = ?, rating = ?, questId = ? WHERE id = ?',[data.answertext, data.rating, data.questId, data.id]);
    }
    catch(error)
    {
        console.log('aaa!');
    }
};

//POST USER
const PostUser = async (data) => {
    try{
        const dbCon = await dbPromise;
        const quest = dbCon.run('INSERT INTO users (email, firstname, lastname, user_type, password) VALUES(?, ?, ?, ?, ?)', [data.email, data.firstname, data.lastname, data.user_type, data.password]);
        return {status: 'ok'};
    }
    catch(error)
    {
        console.log('Could not post to the database!')
    }
};
////
//GET ALL USERS
const getUsers = async () => {
    try {
        const dbCon = await dbPromise;
        const users = await dbCon.all('SELECT id, email, firstname, lastname, user_type, blocked FROM users ORDER BY email ASC');
        return users;
    }
    catch (error) {
        console.log('nåsssss')
    }
};

//EDIT USER
const updateUser = async (data) =>{
    try {
        const dbCon = await dbPromise;
        await dbCon.run('UPDATE users SET email = ?, firstname = ?, lastname = ?, user_type = ?, blocked = ? WHERE id = ?', [data.email, data.firstname, data.lastname, data.user_type, data.blocked, data.id]);
    }
    catch (error) {
        console.log('något gick fel med updatering i databas')
        console.log(error)
    }
};

//GET USER BY ID
const getUser = async (data) => {
    try {
        const dbCon = await dbPromise;
        const user = await dbCon.get('SELECT email, firstname, lastname, user_type, blocked, id FROM users WHERE id = ?', [data]);
        return user;
    }
    catch (error) {
        console.log('något gick fel med hämtingng av user')
    }
};

const removeUser = async (data) => {
    try {
        const dbCon= await dbPromise;
        await dbCon.run('DELETE FROM users WHERE id=?', [data.id]);
        return { status: 'User removed, database updated'}
    }
    catch(error)
    {
        console.log(error)
        throw new Error('Couldnt talk to the database...');
    }
};

module.exports = {
    login: login,
    GetQuestionId: GetQuestionId,
    DeleteQuestion: DeleteQuestion,
    DeleteAnswer : DeleteAnswer,
    GetAnswer : GetAnswer,
    PostQuestion : PostQuestion,
    PostAnswer : PostAnswer,
    UpdateQuestion : UpdateQuestion,
    UpdateAnswer : UpdateAnswer,
    GetAllAnswers : GetAllAnswers,
    GetAllQuestions : GetAllQuestions,
    PostUser : PostUser,
    makeDate : makeDate,
    GetAnswerId : GetAnswerId,
    getUsers : getUsers,
    updateUser: updateUser,
    getUser : getUser,
    removeUser : removeUser,
    DeleteAnswerQID : DeleteAnswerQID
};